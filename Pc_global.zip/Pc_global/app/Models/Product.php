<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use App\Models\ProductDescription;
use App\Models\Category;


class Product extends  Model
{
    use  HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = 'pc_products';
    protected $primaryKey = 'products_id';
    protected $guarded = ['products_id'];
    
    public function descriptions()
    {
        return $this->hasOne(ProductDescription::class, 'products_id', 'products_id');
    }
    public function attributes()
    {
        return $this->hasMany(ProductAttribute::class, 'products_id', 'products_id');
    }

    public function price()
    {
        return $this->hasOne(ProductPriceRate::class, 'products_id', 'products_id');
    }


    // public function products_to_categories(){
    //     return $this->belongsToMany(ProductToCategory::class,'products_id', 'products_id');
    // }


    public function products_to_categories(){
        return $this->belongsToMany(Category::class,('pc_products_to_categories'),'products_id', 'categories_id');
    }


    
}
