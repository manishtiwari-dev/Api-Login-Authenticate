<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use App\Models\ProductOptionValue;
use App\Models\ProductOption;


class ProductAttribute extends  Model
{
    use  HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = 'products_attributes';
    protected $primaryKey = 'products_attributes_id';
    protected $guarded = ['products_attributes_id'];
    
    public function product()
    {
        return $this->belongsToMany(Product::class, 'products_id', 'products_attributes_id');
    }



    public function productOptions(){
        return $this->belongsTo(ProductOption::class, 'options_id', 'products_options_id');
    }

    public function productOptionsValue(){
        return $this->belongsTo(ProductOptionValue::class, 'options_values_id', 'products_options_values_id');
    }


    
}
