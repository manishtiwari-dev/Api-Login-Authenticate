<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Category extends Model
{
    use  HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = 'pc_categories';
    protected $primaryKey = 'categories_id';
    protected $fillable = [
        'categories_id',
        'categories_name',
        'categories_image',
        'categories_icon',
        'show_in_menu',
        'parent_id',
        'sort_order',
        'status',
    ];
    
    public function description()
    {
        return $this->hasOne(CategoryDescription::class, 'categories_id', 'categories_id');
    }
}
