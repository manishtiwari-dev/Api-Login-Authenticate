<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class CategoryDescription extends Model

{
    use  HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table = 'pc_categories_description';
    protected $primaryKey ='categories_id';
    protected $fillable = [
        'categories_id',
        'language_id',
        'categories_name',
        'categories_top_nav_name',
        'categories_heading_title',
        'categories_description',
        'categories_head_title_tag',
        'categories_head_desc_tag',
        'categories_head_keywords_tag',
    ];
}
