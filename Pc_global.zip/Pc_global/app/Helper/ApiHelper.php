<?php
namespace App\Helper;

use App\Models\User;
use DB;


class ApiHelper
{



    public static function JSON_RESPONSE($status, $data = array(), $msg)
    {
        return response()->json([
            'status' => $status,
            'data' => $data,
            'message' => $msg,
        ], ($status) ? 200 : 201);
    }


     
/*
    api token validate
     */
    public static function api_token_validate($token)
    {
        $token_decodeval = base64_decode($token);
        $token_ary = explode('_DB', $token_decodeval);

        // Self::essential_config_regenerate($token_ary[1]);

        // self::init($token_ary[0]);
        $user = User::where('api_token', $token_ary[0])->first();
        return !empty($user) ? true : false;
    }

    public static function get_api_token($token)
    {
        $token_decodeval = base64_decode($token);
        $token_ary = explode('_DB', $token_decodeval);

        if (isset($token_ary[0])) {
            return $token_ary[0];
        } else {
            return null;
        }

    }




    
}