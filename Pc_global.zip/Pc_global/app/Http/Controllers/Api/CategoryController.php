<?php
namespace App\Http\Controllers\Api;
   
use Illuminate\Http\Request;
use App\Http\Controllers\Api\BaseController as BaseController;
use App\Models\Category;
use Validator;
use App\Http\Resources\CategoryResource;
   
class CategoryController extends BaseController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request  $request)
    {
      //  $api_token = $request->api_token;
       
      $language_id = !empty($request->language_id) ? $request->language_id : 1;
      $limit = !empty($request->limit) ? $request->limit : 0;
      $offset = !empty($request->offset) ? $request->offset : 0;
      


      $data_query = Category::with('description')->whereRelation('description', 'language_id', $language_id);

      if($limit)
      $data_query = $data_query->limit($limit);

      if($offset)
      $data_query = $data_query->offset($offset);

      $category = $data_query->get();
  
        return  $this->sendResponse(true,$category,'All Category Retrieved successfully .');
    }


    public function categories(Request  $request)
    {
      

        $language_id = !empty($request->language_id) ? $request->language_id : 1;



        $category = Category::with('description')->whereRelation('description', 'language_id', $language_id)->where('categories_id', $request->categories_id)->get();
    
        return  $this->sendResponse(true,$category,'Category Retrieved successfully .');

    }

}