<?php
   
namespace App\Http\Controllers\Api;
   
use Illuminate\Http\Request;
use App\Http\Controllers\Api\BaseController as BaseController;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductOptionValue;
use App\Models\ProductAttribute;

use Illuminate\Database\Eloquent\Builder;

use Validator;
use App\Http\Resources\CategoryResource;
   
class ProductController extends BaseController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request  $request)
    {
        $language_id = !empty($request->language_id) ? $request->language_id : 1;
        $limit = !empty($request->limit) ? $request->limit : 0;
        $offset = !empty($request->offset) ? $request->offset : 0;

        $data_query = Product::with('descriptions','price','attributes','attributes.productOptions','attributes.productOptionsValue')->whereRelation('descriptions', 'language_id', $language_id);
        
        if($limit)
        $data_query = $data_query->limit($limit);
  
        if($offset)
        $data_query = $data_query->offset($offset);



        $product = $data_query->get();
    
        return  $this->sendResponse(true,$product,'All Product Retrieved successfully .');
    }


    public function product_details(Request  $request)
    {
        $language_id = !empty($request->language_id) ? $request->language_id : 1;

        // $product = Product::with(['descriptions' => function ($query) use( $language_id) {
        //             $query->where('language_id',$language_id);
        //         }])->where('products_id', $request->products_id)->get();

        $product = Product::with('descriptions','price','attributes')->whereRelation('descriptions', 'language_id', $language_id)->where('products_id', $request->products_id)->get();

        return  $this->sendResponse(true,$product,'Product Details Retrieved successfully .');

    }



    
    public function getProducts(Request  $request)
    {
    
        $language_id = !empty($request->language_id) ? $request->language_id : 1;
        $catId=$request->categories_id;
        $data_query =Product::with('descriptions','price','attributes')->whereRelation('descriptions', 'language_id', $language_id);

        if(!empty($catId)){
          
                
            $data_query =$data_query->whereHas('products_to_categories', function (Builder $query) use($catId) {
            $query->where('pc_products_to_categories.categories_id',$catId);
            });
        }
        $product = $data_query->get();
    
        return  $this->sendResponse(true,$product,'  Products  Retrieved successfully .');

    }


    public function getProductAttributes(Request  $request)
    {
      
        $product = ProductAttribute::with('productOptions','productOptionsValue')->where('products_id' ,$request->products_id)->get();

       // $product = $data_query->get();
    
        return  $this->sendResponse(true,$product,'Product Attributes Retrieved successfully .');

    }



}