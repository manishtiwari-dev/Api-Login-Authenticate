<?php
  
namespace App\Http\Resources;
   
use Illuminate\Http\Resources\Json\JsonResource;
  
class CategoryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'categories_id' => $this->categories_id,
            'categories_name' => $this->categories_name,
            'categories_image' => $this->categories_image,
            'categories_icon' => $this->categories_icon,
            'parent_id' => $this->parent_id,
            'sort_order' => $this->sort_order,
            'status' => $this->status,
            'show_in_menu' => $this->show_in_menu,
            'date_added' => $this->date_added,
            'last_modified' => $this->last_modified,
            // 'date_added' => $this->date_added->format('d/m/Y'),
            // 'last_modified' => $this->last_modified->format('d/m/Y'),
        ];
    }
}