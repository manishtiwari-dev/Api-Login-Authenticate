<?php
  
namespace App\Http\Resources;
   
use Illuminate\Http\Resources\Json\JsonResource;
  
class CategoryDescription extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'categories_id' => $this->categories_id,
            'language_id' => $this->language_id,
            'categories_name' => $this->categories_name,
            'categories_top_nav_name' => $this->categories_top_nav_name,
            'categories_heading_title' => $this->categories_heading_title,
            'categories_description' => $this->categories_description,
            'categories_head_title_tag' => $this->categories_head_title_tag,
            'categories_head_desc_tag' => $this->categories_head_desc_tag,
            'categories_head_keywords_tag' => $this->categories_head_keywords_tag,
        ];
    }
}