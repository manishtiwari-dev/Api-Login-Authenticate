<?php
  
namespace App\Http\Resources;
   
use Illuminate\Http\Resources\Json\JsonResource;
  
class ProductResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'products_id' => $this->products_id,
            'products_quantity' => $this->products_quantity,
            'products_model' => $this->products_model,
            'products_price' => $this->products_price,
            'products_weight' => $this->products_weight,
            'products_length' => $this->products_length,
            'products_width' => $this->products_width,
            'products_height' => $this->products_height,
            'products_unit' => $this->products_unit,
            'qty_per_carton' => $this->qty_per_carton,
            'carton_weight' => $this->carton_weight,
            'carton_airwt' => $this->carton_airwt,
            'carton_height' => $this->carton_height,
            'carton_length' => $this->carton_length,
            'carton_width' => $this->carton_width,
            'products_status' => $this->products_status,
            'products_tax_class_id' => $this->products_tax_class_id,
            'manufacturers_id' => $this->manufacturers_id,            
            'products_ordered' => $this->products_ordered,            
            'products_parent_id' => $this->products_parent_id,            
            'products_price1' => $this->products_price1,            
            'products_price2' => $this->products_price2,            
            'products_price3' => $this->products_price3,            
            'products_price4' => $this->products_price4,            
            'products_price5' => $this->products_price5,            
            'products_price6' => $this->products_price6,            
            'products_price7' => $this->products_price7,            
            'products_price8' => $this->products_price8,            
            'products_price9' => $this->products_price9,            
            'products_price10' => $this->products_price10,            
            'products_price11' => $this->products_price11,            
            'products_price1_qty' => $this->products_price1_qty,            
            'products_price2_qty' => $this->products_price2_qty,            
            'products_price3_qty' => $this->products_price3_qty,            
            'products_price4_qty' => $this->products_price4_qty,            
            'products_price5_qty' => $this->products_price5_qty,            
            'products_price6_qty' => $this->products_price6_qty,            
            'products_price7_qty' => $this->products_price7_qty,            
            'products_price8_qty' => $this->products_price8_qty,            
            'products_price9_qty' => $this->products_price9_qty,            
            'products_price10_qty' => $this->products_price10_qty,            
            'products_price11_qty' => $this->products_price11_qty,            
            'products_qty_blocks' => $this->products_qty_blocks,            
            'products_imprint_length' => $this->products_imprint_length,            
            'products_imprint_width' => $this->products_imprint_width,            
            'products_imprint_height' => $this->products_imprint_height,            
            'products_imprint_unit' => $this->products_imprint_unit,            
            'products_imprint_method' => $this->products_imprint_method,            
            'packing_method' => $this->packing_method,            
            'color_option' => $this->color_option,            
            'products_jpeg_digital_proof' => $this->products_jpeg_digital_proof,            
            'products_vector_digital_proof' => $this->products_vector_digital_proof,
            'products_papachina_video_url' => $this->products_papachina_video_url,  
            'products_promo_video_url' => $this->products_promo_video_url,          
            'products_in_use_photo' => $this->products_in_use_photo,            
            'products_on_hand' => $this->products_on_hand,            
            'products_hand_photo_id' => $this->products_hand_photo_id,            
            'products_eco_tags' => $this->products_eco_tags,            
            'products_images_path' => $this->products_images_path,            
            'products_default_color' => $this->products_default_color,            
            'sort_order' => $this->sort_order,            
            'products_date_added' => $this->products_date_added,            
            'products_last_modified' => $this->products_last_modified,            
            'products_date_available' => $this->products_date_available,  
        ];
    }
}