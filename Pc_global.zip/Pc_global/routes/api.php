<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\RegisterController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\ProductController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/


Route::controller(RegisterController::class)->group(function(){
    Route::post('register', 'register');
    Route::post('login', 'login');
});




Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
  
    return $request->user();
});




// authenticated api

Route::middleware('auth:sanctum')->group( function () {

    Route::post('getAllCategories', [CategoryController::class,'index']);
    Route::post('/categories', [CategoryController::class,'categories']);
    Route::post('getAllproducts', [ProductController::class,'index']);
    Route::post('productDetails', [ProductController::class,'product_details']);
    Route::post('getProducts', [ProductController::class,'getProducts']);
    Route::post('getProductAttributes', [ProductController::class,'getProductAttributes']);

    Route::post('me', [RegisterController::class,'me']);
});


//end 




